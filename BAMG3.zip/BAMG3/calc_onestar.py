"""
Calculate membership probability for all input data
--- Choice of model update method (member selection method)
--- save p(MG) and flag.
"""


from bayesian_membership import * 
from datetime import datetime
import matplotlib.pyplot as plt
import inspect


groups = dict([(1,'TWA'),(2,'BPMG'),(3,'ThOrCol'),(4,'TucHorCol'),(5,'Carina'),(6,'Argus'),(7,'ABDor'),(8,'VCA')])
ageclasses = np.array([1,2,3,3,3,3,4,4])

thisfile = inspect.getfile(inspect.currentframe())

t0 = datetime.now()

fname = 'stage3_mp390_wratio100_pcut90_rev10'
wratio = 100.0  #Nfld / Nmg

outdir = './analysis/'


# input data
##pos = raw_input("ra de (deg) => ")
#rastr = raw_input("ra (hh mm ss) ==> ")
#destr = raw_input("de (dd mm ss) ==> ")
#pms = raw_input("pmra epmra pmde epmde (mas/yr)==>")
#plxs = raw_input("plx eplx (mas; if not exist, press enter) ==>")
#rvs = raw_input("rv erv (km/s; if not exist, press enter) ==>")

rastr = input("ra (hh mm ss) ==> ")
destr = input("de (dd mm ss) ==> ")
pms   = input("pmra epmra pmde epmde (mas/yr)==>")
plxs  = input("plx eplx (mas; if not exist, press enter) ==>")
rvs   = input("rv erv (km/s; if not exist, press enter) ==>")




rah,ram,ras = [float(x) for x in rastr.split()]
ded,dem,des = [float(x) for x in destr.split()]
ra = (rah+ram/60.0+ras/3600.0)*15.0
de = abs(ded) + dem/60.0+des/3600.
if ded < 0: de = -de

pmra,epmra,pmde,epmde = pms.split()

ra,de = float(ra),float(de)
pmra,epmra,pmde,epmde = float(pmra),float(epmra),float(pmde),float(epmde)

try:
    plx,eplx = plxs.split()
    plx,eplx = float(plx),float(eplx)
except:
    plx,eplx,dist,edist= np.nan,np.nan,np.nan,np.nan

try:
    rv,erv = rvs.split()
    rv,erv = float(rv),float(erv)
except:
    rv,erv = np.nan,np.nan

p = calculation('star',ra,de,pmra,epmra,pmde,epmde,plx,eplx,rv,erv,fname=fname,wratio=wratio)
p.posterior()

probs = p.prob

print("----------Membership probability--------------")
print("TWA       : %.1f" %probs[0])
print("BPMG      : %.1f" %probs[1])
print("ThOr-Col  : %.1f" %probs[2])
print("TucHor-Col: %.1f" %probs[3])
print("Carina    : %.1f" %probs[4])
print("Argus     : %.1f" %probs[5])
print("ABDor     : %.1f" %probs[6])
print("VCA       : %.1f" %probs[7])
print("Field     : %.1f" %sum(probs[8:]))




"""
Calculate membership probability for all input data
--- Choice of model update method (member selection method)
--- save p(MG) and flag.
"""


from bayesian_membership import * 
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import inspect


groups = dict([(1,'TWA'),(2,'BPMG'),(3,'ThOrCol'),(4,'TucCol'),(5,'Carina'),(6,'Argus'),(7,'ABDor'),(8,'VCA')])
ageclasses = np.array([1,2,3,3,3,3,4,4])

thisfile = inspect.getfile(inspect.currentframe())

t0 = datetime.now()

fname = 'stage3_mp390_wratio100_pcut90_rev10'
indir = './'
infile = 'fulldata_updated.pickle'
df = pd.read_pickle(indir+infile)

df= df.assign(prob0=nan,prob1=nan,prob2=nan,prob3=nan,prob4=nan,prob5=nan,prob6=nan,prob7=nan,prob8=nan)

#wratio = 1
wratio = 100.0  #Nfld / Nmg
outdir = './analysis/'
outfile = 'all_memba_mdl%s_wratio%i' %(fname,wratio)

fout = open(outdir+outfile+'.prob','w')
fout.write("#                         name        spt           ra           de    pmra  epmra    pmde  epmde     plx   eplx      rv    erv     twa    bpmg   thor tuchor carina columba argus  abdor  vca field \n")


for idx,s in df.iterrows():
    print("calculating.... %i/%i" %(idx,len(df)))

    p = calculation(s['name'],s.ra,s.de,s.pmra,s.epmra,s.pmde,s.epmde,s.plx,s.eplx,s.rv,s.erv,fname=fname,wratio=wratio)
    p.posterior()

    probs = p.prob #idx]

    df.loc[idx,'prob0']=p.prob[0]
    df.loc[idx,'prob1']=p.prob[1]
    df.loc[idx,'prob2']=p.prob[2]
    df.loc[idx,'prob3']=p.prob[3]
    df.loc[idx,'prob4']=p.prob[4]
    df.loc[idx,'prob5']=p.prob[5]
    df.loc[idx,'prob6']=p.prob[6]
    df.loc[idx,'prob7']=p.prob[7]
    df.loc[idx,'prob8']=p.prob[8]

    outtxt = "%30s %10s %12.7f %12.7f %7.2f %6.2f %7.2f %6.2f %7.2f %6.2f %7.2f %6.2f   " %(s['name'],s.spt,s.ra,s.de,s.pmra,s.epmra,s.pmde,s.epmde,s.plx,s.eplx,s.rv,s.erv)

    for ii in range(len(groups)):
        outtxt += "%6.2f " %(probs[ii])
    outtxt += "%6.2f\n" %(sum(probs[ii+1:]))
    fout.write(outtxt)

fout.close()

t1 = datetime.now()
print("calculation took...... %s.. (N=%i)" %(t1-t0,len(df)))


### for a small check


groups = dict([(1,'twa'),(2,'bpmg'),(3,'thor'),(4,'tuchor'),(5,'carina'),(6,'columba'),(7,'argus'),(8,'abdor'),(9,'vca')])
ageclasses = np.array([1,2,2,3,3,3,3,4,4])



gidxs = np.arange(1,10,1) 
#gidx = input("select groups (type number): (1:twa,2:bpmg,3:thor,4:tuchor,5:carina,6:columba,7:argus,8:abdor)")

for gidx in gidxs:

    gidx = int(gidx)
    grp = groups[gidx]
    grpage = ageclasses[gidx-1]
    
    
    S1 = df['grp%i' %gidx] > 0
    S2 = df['flag_kin'] == 1
    S3 = df['ageclass'] <= grpage
    S4 = df['flag_ini_grp%i' %gidx ] ==1
    
    df_memb = df[S1&S2&S3]
    df_imem = df[S1&S2&S3&S4]

    df_memb = df_memb.sort_values(by=['prob%i' %(gidx-1)],ascending=False)
    df_imem = df_imem.sort_values(by=['prob%i' %(gidx-1)],ascending=False)
    df_memb = df_memb.reset_index(drop=True)
    df_imem = df_imem.reset_index(drop=True)

    fig,ax = plt.subplots(ncols=1,nrows=2,figsize=(10,10))
    ax[0].plot(df_imem['prob%i' %(gidx-1)],'o-')
    ax[1].plot(df_memb['prob%i' %(gidx-1)],'o-')

   


    ax[0].grid(ls=':') 
    ax[1].grid(ls=':')
    ax[0].set_xlabel("idx") ; ax[0].set_ylabel("prob")
    ax[1].set_xlabel("idx") ; ax[1].set_ylabel("prob")

    fig.suptitle(grp,fontsize=20)


    ax[0].set_ylim(-5,105)
    ax[1].set_ylim(-5,105)

    plt.annotate(thisfile,xy=(0.1,0.95),xycoords='figure fraction',fontsize=8)
    plt.annotate(fname,xy=(0.1,0.9),xycoords='figure fraction',fontsize=12)



plt.show()






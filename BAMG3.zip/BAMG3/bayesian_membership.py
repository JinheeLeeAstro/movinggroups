"""Calculating membership probability

   How to use:

   1) from bayesian_membership import *
   2) prob = calculation('name',ra,de,pmra,epmra,pmde,epmde,plx,eplx,rv,erv,fname='i0',wratio = 1)  # wratio: N(MG)/N(FLD)
   3) prob.posterior()

   check the result
      print(prob.prob)     
   
   ...


### if you have many stars.....
   1) from calculation_cls import *
   2) calc = calculation(fname='i0')
   3) mdl = calc.load_models()
   4) for stars...
         calc.input_data(ra,de,,,,etc)
         prior = calc.calc_prior()
         likelihood = calc.calc_likelihood()
         ... need to calculate star by star


* All kinematic parameters should be inserted as numbers (None is not accepted - transform to NaN)


"""

import warnings
from os.path import dirname
import numpy as np
import pandas as pd
import uga.coords as coords
import json
from astropy.table import Table
from numpy import nan
d2r = np.pi/180.
fld_ncomp = 4
Nsample = 1e6 # for priorPDF file

#warnings.simplefilter('always')

class calculation():
    """ Membership probability calculation.

    Attributes:
        name,ra,de,pmra,epmra,pmde,epmde,plx,eplx,rv,erv : star's data
        update_method: model update method (0: initial, 1_incl, 1_excl, 2)
        echa,twa,bpmg,thor,tuchor,carina,columba,argus,abdor,fld: membership probability. (sum=100)
    """


    def __init__(self,name='',ra=nan,de=nan,pmra=nan,epmra=nan,pmde=nan,epmde=nan,plx=nan,eplx=nan,rv=nan,erv=nan,fname='i0',wratio = 100.):
        """Return a probability object."""
        self.name = name
        self.ra = ra
        self.de = de
        self.pmra = pmra/1000.  # as
        try:    self.epmra = epmra/1000. ; dum = int(self.epmra) ; dum2 = 1/self.epmra # in case of NaN and zero
        except:  self.epmra = abs(self.pmra)*0.2
        self.pmde = pmde/1000.
        try:        self.epmde = epmde/1000. ; dum = int(self.epmde) ; dum2 = 1/self.epmde
        except:     self.epmde = abs(self.pmde)*0.2

        self.plx = plx
        try:        self.eplx = eplx    ; dum = int(self.eplx) ;  dum2 = 1/self.eplx
        except:     self.eplx = abs(self.plx)*0.2
        self.rv = rv
        try:        self.erv = erv      ; dum = int(self.erv) ; dum3 = 1/self.erv
        except:     self.erv = abs(self.rv)*0.2
        self.dist = 1000./self.plx
        self.edist = 1000.*self.eplx/self.plx**2
        gl, gb = coords.eq2gal(self.ra,self.de,b1950=False)
        pm = np.sqrt(self.pmra**2.+self.pmde**2.)
        epm = np.sqrt((self.pmra/pm*self.epmra)**2. + (self.pmde/pm*self.epmde)**2.)

        self.pm = pm
        self.epm = epm
        self.gl = gl
        self.gb = gb

        self.fname = fname
        self.wratio = wratio # N(FLD)/N(MG)

        self.prob = [0,0,0,0,0,0,0,0]


    def load_models(self):
        groups = ['TWA','BPMG','ThOrCol','TucCol','Carina','Argus','ABDor','VCA']
        mdir = dirname(__file__)+'/models/'
    
        cols = ['grp','xc','yc','zc','sigx','sigy','sigz','a1','a2','a3','uc','vc','wc','sigu','sigv','sigw','b1','b2','b3','weight']
        gmdl = pd.DataFrame(columns=cols)

        for i,grp in enumerate(groups):
            with open(mdir+'%s_xyz_%s.json' %(grp,self.fname)) as f:
                mdlxyz = json.load(f)
            with open(mdir+'%s_uvw_%s.json' %(grp,self.fname)) as f:
                mdluvw = json.load(f)
            
            xc,yc,zc = mdlxyz['center']
            sigx,sigy,sigz = mdlxyz['sigma']
            a1,a2,a3 = mdlxyz['angle']
            uc,vc,wc = mdluvw['center']
            sigu,sigv,sigw = mdluvw['sigma']
            b1,b2,b3 = mdluvw['angle']
            weight = 1./float(self.wratio)/len(groups)            

            row = pd.DataFrame({'grp':grp,'xc':xc,'yc':yc,'zc':zc,'sigx':sigx,'sigy':sigy,'sigz':sigz,'a1':a1,'a2':a2,'a3':a3,'uc':uc,'vc':vc,'wc':wc,'sigu':sigu,'sigv':sigv,'sigw':sigw,'b1':b1,'b2':b2,'b3':b3,'weight':weight},index=[i])
            gmdl=gmdl.append(row,sort=True) 
 
        return gmdl


    def load_models_fld(self):
        mdir = dirname(__file__)+'/models/field/'
        mfile = 'gaia_300pc_uvw_model%icomp.fits' %fld_ncomp
        fmdls = Table.read(mdir+mfile,format='fits')

        cols = ['grp','xc','yc','zc','sigx','sigy','sigz','a1','a2','a3','uc','vc','wc','sigu','sigv','sigw','b1','b2','b3','weight']
        fmdl = pd.DataFrame(columns=cols)
        for i, row in enumerate(fmdls):
            xc,yc,zc = 0,0,0
            sigx,sigy,sigz = 200,200,200
            a1,a2,a3 = 0,0,0
            uc,vc,wc = row['center']
            sigu,sigv,sigw = row['sigma']
            b1,b2,b3 = row['angle']
            grp = row['grp'][0].decode('utf-8')
 
            ff = pd.DataFrame({'grp':grp,'xc':xc,'yc':yc,'zc':zc,'sigx':sigx,'sigy':sigy,'sigz':sigz,'a1':a1,'a2':a2,'a3':a3,'uc':uc,'vc':vc,'wc':wc,'sigu':sigu,'sigv':sigv,'sigw':sigw,'b1':b1,'b2':b2,'b3':b3,'weight':row['weight']},index=[i])
            fmdl = fmdl.append(ff,sort=True)
        return fmdl


    def calc_prior(self,mdls):
        """ calculate for each groups """

        priordir = dirname(__file__)+'/priorPDFs/'
        priors = []
        for i,row in mdls.iterrows():
            if row['grp'][:5] == 'field': pfile = 'N%ifld/priorPDF_%s_%i.txt' %(fld_ncomp,row.grp,Nsample)
            else:                         pfile = '%s_priorPDF_mdl%s_%i.txt' %(row.grp,self.fname,Nsample)
            rv,p_rv,dist,p_dist,gb,p_gb,pm,p_pm = np.loadtxt(priordir+pfile,delimiter=',',unpack=True)
         
            # 1. RV prior
            drv = abs(rv[1]-rv[0]) ; prior_rv = 0.
            if np.isfinite(self.rv):
                for j in range(len(rv)):
                    prior_rv = prior_rv + np.exp(-0.5*(rv[j]-self.rv)**2./self.erv**2.) * p_rv[j]*drv
                erv_obs = self.erv
            else:   prior_rv = 1. ; erv_obs = 1.
         
            # 2. Dist prior
            ddist = abs(dist[1]-dist[0]) ; prior_dist = 0.
            if np.isfinite(self.dist):
                for j in range(len(dist)):
                    prior_dist = prior_dist + np.exp(-0.5*(dist[j]-self.dist)**2./self.edist**2.) * p_dist[j] * ddist
                edist_obs = self.edist
            else:   prior_dist = 1. ; edist_obs = 1.
         
            # 3. proper motion prior
            dpm = abs(pm[1]-pm[0]) ; prior_pm = 0.
            for j in range(len(pm)):
                prior_pm = prior_pm + np.exp(-0.5*(pm[j]-self.pm)**2./self.epm**2.) * p_pm[j] * dpm
            epm_obs = self.epm         

            # 4. galactic latitude
            dgb = abs(gb[1]-gb[0]) ; prior_gb = 0.
            idx, num = min(enumerate(gb), key=lambda x: abs(x[1]-self.gb))
            prior_gb = p_gb[idx] * dgb
         
            prior_rv = prior_rv/erv_obs
            prior_dist = prior_dist/edist_obs
            prior_pm = prior_pm/epm_obs
            prior_gb = prior_gb

            prior = prior_rv * prior_dist * prior_pm * prior_gb * row.weight
            priors.append(prior)
        priors = np.array(priors) 
        return priors  





    def calc_likelihood(self,mdls):


        def calc_TA(ra,de):
                            
            c_ra = np.cos(ra*d2r)
            s_ra = np.sin(ra*d2r)
            c_de = np.cos(de*d2r)
            s_de = np.sin(de*d2r)
            A1 = np.array([[c_ra,s_ra,0],[s_ra,-c_ra,0],[0,0,-1]])
            A2 = np.array([[c_de,0,-s_de],[0,-1,0],[-s_de,0,-c_de]])
            A = np.dot(A1,A2)
         
        # for NGP
            a_ngp = 192.859508
            d_ngp = 27.128336
            t_ngp = 122.932
         
            T = np.array([[-0.0548755604,-0.8734370902,-0.4838350155],[0.4941094279,-0.4448296300,0.7469822445],[-0.8676661490,-0.1980763734,0.4559837762]])  # Gagne
            TA = np.dot(T,A)
         
            return TA




        likelihoods, statdists, statrvs = [],[],[]
             
        for i,row in mdls.iterrows():
             
            a1,a2,a3,b1,b2,b3 = row.a1,row.a2,row.a3,row.b1,row.b2,row.b3
            xc,yc,zc,uc,vc,wc = row.xc,row.yc,row.zc,row.uc,row.vc,row.wc
            sigx,sigy,sigz    = row.sigx,row.sigy,row.sigz
            sigu,sigv,sigw    = row.sigu,row.sigv,row.sigw
             
            # 1. xyz # not necessary for Gaussian

            if row['grp'][:5] == 'field':
                pass
            else:
                R1_S = np.array([[np.cos(a1),-np.sin(a1),0.],[np.sin(a1),np.cos(a1),0.],[0.,0.,1.]])
                R2_S = np.array([[np.cos(a2),0.,np.sin(a2)],[0.,1.,0.],[-np.sin(a2),0.,np.cos(a2)]])
                R3_S = np.array([[1.,0.,0.],[0.,np.cos(a3),-np.sin(a3)],[0.,np.sin(a3),np.cos(a3)]])
                 
                Rot_S1 = np.dot(R2_S,R3_S)
                Rot_SFin = np.dot(R3_S,np.dot(R2_S,R1_S))
             
            # 2. uvw
            R1_D = np.array([[np.cos(b1),-np.sin(b1),0],[np.sin(b1),np.cos(b1),0],[0.,0.,1.]])
            R2_D = np.array([[np.cos(b2),0,np.sin(b2)],[0.,1.,0.],[-np.sin(b2),0,np.cos(b2)]])
            R3_D = np.array([[1.,0.,0.],[0,np.cos(b3),-np.sin(b3)],[0,np.sin(b3),np.cos(b3)]])
             
            Rot_D1 = np.dot(R2_D,R3_D)
            Rot_DFin = np.dot(R3_D,np.dot(R2_D,R1_D))
             
             
    ##### final likelihood: p_rv_i*p_dist_j * PxPyPzPuPvPw * d(rv) * d(dist)
    #####                 : therefore, only p_rv > 0 & p_dist > 0 region considered
    #####                   need to read priorPDF files
            priordir = dirname(__file__)+'/priorPDFs/'
            if row['grp'][:5] == 'field': pfile = 'N%ifld/priorPDF_%s_%i.txt' %(fld_ncomp,row.grp,Nsample)
            else:                         pfile = '%s_priorPDF_mdl%s_%i.txt' %(row.grp,self.fname,Nsample)
            rv,p_rv,dist,p_dist,gb,p_gb,pm,p_pm = np.loadtxt(priordir+pfile,delimiter=',',unpack=True)
            didx ,= np.where(p_dist > 0.)
            ridx ,= np.where(p_rv > 0.)
             
            distrange = np.arange(didx[0],didx[-1],int(len(didx)*0.3))   # sample 30 percent of index
            rvrange   = np.arange(ridx[0],ridx[-1],int(len(ridx)*0.3))   # sample 30 percent of index
             
            ddist = abs(dist[distrange[1]]-dist[distrange[0]])
            drv   = abs(rv[rvrange[1]]-rv[rvrange[0]])
            dist_err = np.zeros(len(dist))   # 0 error in case of dist not observed (no error assumed)
            rv_err   = np.zeros(len(rv))
    
    ##### define some parameters for reducing calculation time.
            xx = np.cos(self.gb*d2r)*np.cos(self.gl*d2r)
            yy = np.cos(self.gb*d2r)*np.sin(self.gl*d2r)
            zz = np.sin(self.gb*d2r)
             
            TA = calc_TA(self.ra,self.de)
            K = 4.743717361  # Gagne IDL procedure
             
             
    ##### calculate likelihood
             
            if np.isfinite(self.dist):
                dist = [self.dist] ; dist_err = [self.edist]
                ddist= 1.0 ; p_dist = [1.] ; distrange=[0]
            if np.isfinite(self.rv):
                rv = [self.rv] ; rv_err = [self.erv]
                drv = 1.0 ;p_rv = [1.] ; rvrange=[0]
             
    ##### define result array : dist(col) x rv(row) filled with likelihood
            resultarr = np.zeros([len(distrange)+1,len(rvrange)+1])
             
            for iid, ii in enumerate(distrange):
                resultarr[iid+1,0] = dist[ii]
             
                x = xx*dist[ii]
                y = yy*dist[ii]
                z = zz*dist[ii]

                # split uniform vs Gaussian case

                if row['grp'][:5] == 'field':
                    volume = 4*np.pi/3.*sigx*sigy*sigz  # 200 pc sphere
                    p = 1./volume
                    sphere = (x-xc)**2/sigx**2 + (y-yc)**2/sigy**2 + (z-zc)**2/sigz**2
                    if sphere < 1. : likeX = p**(1./3) ; likeY,likeZ = likeX,likeX
                    else: likeX,likeY,likeZ = 0,0,0
 
                else:
                    dx = xx*dist_err[ii]
                    dy = yy*dist_err[ii]
                    dz = zz*dist_err[ii]
                 
                    xp = Rot_SFin[0][0]*(x-xc) + Rot_SFin[0][1]*(y-yc) + Rot_SFin[0][2]*(z-zc) + xc
                    yp = Rot_SFin[1][0]*(x-xc) + Rot_SFin[1][1]*(y-yc) + Rot_SFin[1][2]*(z-zc) + yc
                    zp = Rot_SFin[2][0]*(x-xc) + Rot_SFin[2][1]*(y-yc) + Rot_SFin[2][2]*(z-zc) + zc
                 
                    dxp = np.sqrt((Rot_SFin[0][0]*dx)**2 + (Rot_SFin[0][1]*dy)**2 + (Rot_SFin[0][2]*dz)**2)
                    dyp = np.sqrt((Rot_SFin[1][0]*dx)**2 + (Rot_SFin[1][1]*dy)**2 + (Rot_SFin[1][2]*dz)**2)
                    dzp = np.sqrt((Rot_SFin[2][0]*dx)**2 + (Rot_SFin[2][1]*dy)**2 + (Rot_SFin[2][2]*dz)**2)
                 
                    Xerr = np.sqrt(sigx**2 + dxp**2)
                    Yerr = np.sqrt(sigy**2 + dyp**2)
                    Zerr = np.sqrt(sigz**2 + dzp**2)
                 
                    likeX = np.exp(-0.5*(xp-xc)**2./Xerr**2.) / Xerr / np.sqrt(2.*np.pi)
                    likeY = np.exp(-0.5*(yp-yc)**2./Yerr**2.) / Yerr / np.sqrt(2.*np.pi)
                    likeZ = np.exp(-0.5*(zp-zc)**2./Zerr**2.) / Zerr / np.sqrt(2.*np.pi)
             
                for jjr, jj in enumerate(rvrange): # range(len(rv)):
             
                    resultarr[0,jjr+1] = rv[jj]
             
                    arr = np.array([rv[jj], K*self.pmra*dist[ii], K*self.pmde*dist[ii]])
                    u,v,w = np.dot(TA, arr)
             
                    erv = False
    
                    du = np.sqrt( (TA[0][0]*rv_err[jj])**2.+(TA[0][1]*K)**2*((self.epmra*dist[ii])**2+(self.pmra*dist_err[ii])**2+(self.epmra*dist_err[ii])**2) + (TA[0][2]*K)**2*((self.epmde*dist[ii])**2+(self.pmde*dist_err[ii])**2+(self.epmde*dist_err[ii])**2 ))
                    dv = np.sqrt( (TA[1][0]*rv_err[jj])**2.+(TA[1][1]*K)**2*((self.epmra*dist[ii])**2+(self.pmra*dist_err[ii])**2+(self.epmra*dist_err[ii])**2) + (TA[1][2]*K)**2*((self.epmde*dist[ii])**2+(self.pmde*dist_err[ii])**2+(self.epmde*dist_err[ii])**2 ))
                    dw = np.sqrt( (TA[2][0]*rv_err[jj])**2.+(TA[2][1]*K)**2*((self.epmra*dist[ii])**2+(self.pmra*dist_err[ii])**2+(self.epmra*dist_err[ii])**2) + (TA[2][2]*K)**2*((self.epmde*dist[ii])**2+(self.pmde*dist_err[ii])**2+(self.epmde*dist_err[ii])**2 ))
             
                    up = Rot_DFin[0][0]*(u-uc) + Rot_DFin[0][1]*(v-vc) + Rot_DFin[0][2]*(w-wc) + uc
                    vp = Rot_DFin[1][0]*(u-uc) + Rot_DFin[1][1]*(v-vc) + Rot_DFin[1][2]*(w-wc) + vc
                    wp = Rot_DFin[2][0]*(u-uc) + Rot_DFin[2][1]*(v-vc) + Rot_DFin[2][2]*(w-wc) + wc
             
                    dup = np.sqrt((Rot_DFin[0][0]*du)**2 + (Rot_DFin[0][1]*dv)**2 + (Rot_DFin[0][2]*dw)**2 )
                    dvp = np.sqrt((Rot_DFin[1][0]*du)**2 + (Rot_DFin[1][1]*dv)**2 + (Rot_DFin[1][2]*dw)**2 )
                    dwp = np.sqrt((Rot_DFin[2][0]*du)**2 + (Rot_DFin[2][1]*dv)**2 + (Rot_DFin[2][2]*dw)**2 )
             
                    Uerr = np.sqrt(dup**2. + sigu**2.)
                    Verr = np.sqrt(dvp**2. + sigv**2.)
                    Werr = np.sqrt(dwp**2. + sigw**2.)
             
                    likeU = np.exp(-0.5*(up-uc)**2./Uerr**2.) / Uerr / np.sqrt(2.*np.pi)
                    likeV = np.exp(-0.5*(vp-vc)**2./Verr**2.) / Verr / np.sqrt(2.*np.pi)
                    likeW = np.exp(-0.5*(wp-wc)**2./Werr**2.) / Werr / np.sqrt(2.*np.pi)
             
             
                    like =  p_rv[jj] * p_dist[ii] * likeX * likeY * likeZ * likeU * likeV * likeW * drv * ddist
             
                    resultarr[iid+1,jjr+1] = like
             
            likearr = np.array(resultarr[1:,1:])
             
             
            idx = np.where(likearr == np.max(likearr))
            statdist = resultarr[idx[0]+1,0]
            statrv = resultarr[0,idx[1]+1]
             
            likelihood = likearr.sum()
             
            likelihoods.append(likelihood)
            statdists.append(statdist)
            statrvs.append(statrv)
         
             
        likelihoods = np.array(likelihoods)
        return likelihoods,statdists,statrvs



    def posterior(self, *args, **kw):
        """ calculating posterior """
        gmdls = self.load_models()
        fmdls = self.load_models_fld()
        mdls = pd.concat([gmdls,fmdls])

        mdls = mdls.reset_index(drop=True)

        priors = self.calc_prior(mdls)
        likelihoods,statdists,statrvs = self.calc_likelihood(mdls)
        posterior = priors*likelihoods
        # normalize
        NORM = np.sum(posterior)
        p = 100.*posterior/NORM
  
        self.prob = p    

        return

            
    def input_data(self,name,ra,de,pmra,epmra,pmde,epmde,plx,eplx,rv,erv):
        self.name = name
        self.ra = ra
        self.de = de
        self.pmra = pmra/1000.  # as
        try:    self.epmra = epmra/1000. ; dum = int(self.epmra)  ; dum2 = 1./self.epmra # in case of NaN or 0
        except:  self.epmra = abs(self.pmra)*0.2
        self.pmde = pmde/1000.
        try:        self.epmde = epmde/1000. ; dum = int(self.epmde) ; dum2 = 1/self.epmde
        except:     self.epmde = abs(self.pmde)*0.2

        self.plx = plx
        try:        self.eplx = eplx    ; dum = int(self.eplx) ; dum2 = 1/self.eplx
        except:     self.eplx = abs(self.plx)*0.2
        self.rv = rv
        try:        self.erv = erv      ; dum = int(self.erv) ; dum3 = 1/self.erv
        except:     self.erv = abs(self.rv)*0.2
        self.dist = 1000./self.plx
        self.edist = 1000.*self.eplx/self.plx**2
        gl, gb = coords.eq2gal(self.ra,self.de,b1950=False)
        pm = np.sqrt(self.pmra**2.+self.pmde**2.)
        epm = np.sqrt((self.pmra/pm*self.epmra)**2. + (self.pmde/pm*self.epmde)**2.)

        self.pm = pm
        self.epm = epm
        self.gl = gl
        self.gb = gb


